﻿using System.Text;

namespace Egaku.Rendering.Pipeline.Utility {
    
    
    public static class StringUtils {
        

    }
}