﻿using System.Linq.Expressions;
using Egaku.Rendering.Pipeline.Common;
using NUnit.Framework;

namespace Tests {
	public class CodeGeneratorTests {

		
		[Test]
		public void GenerateCode() {

		}
	}
}