﻿using System.Collections.Generic;

namespace Egaku.Rendering.Pipeline.Common {
    
    
    public abstract class RenderFeature {

        public virtual void SetupRenderPasses() {
            
        }

        public virtual IEnumerable<RenderPassNode> GetRenderPassNodes() {
            return null;
        }
        
        

    }
}