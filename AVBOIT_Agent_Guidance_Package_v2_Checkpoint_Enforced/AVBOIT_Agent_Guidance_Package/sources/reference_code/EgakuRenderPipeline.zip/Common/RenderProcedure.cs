﻿using System;
using UnityEngine.UIElements;

namespace Egaku.Rendering.Pipeline.Common {

    public class D {
        private Action t;
    }
    
    public delegate void RenderProcedure<TInput>();
    
    public interface IRenderProcedure {
        public void Execute<TInput>(TInput input);
    }
    
}