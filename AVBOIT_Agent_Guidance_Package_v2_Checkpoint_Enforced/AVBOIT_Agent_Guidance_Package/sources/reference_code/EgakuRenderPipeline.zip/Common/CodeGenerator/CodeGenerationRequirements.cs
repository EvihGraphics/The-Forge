﻿namespace Egaku.Rendering.Pipeline.Common {
    public enum CodeGenerationRequirements {
        CSharpParamTable = 0x1,
        ShaderParamDefinition = 0x4,
        ShaderParamHelperStruct = 0x8,
        ShaderParamGetter = 0x10
    }
}