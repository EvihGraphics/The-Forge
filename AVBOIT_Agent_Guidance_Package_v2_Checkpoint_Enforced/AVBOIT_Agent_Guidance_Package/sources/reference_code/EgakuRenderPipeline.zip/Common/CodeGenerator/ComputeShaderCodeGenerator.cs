﻿namespace Egaku.Rendering.Pipeline.Common {
    
    
    public class ComputeShaderCodeGenerator  : HLSLCodeGenerator{
        public ComputeShaderCodeGenerator(string directory,string fileName):base(directory,fileName) {
        }
        
        public ComputeShaderCodeGenerator() {
        }
        

        public void EmitKernelDeclaration(string kernelSymbol) {
            EmitPragmaDirective($"kernel {kernelSymbol}");
        }
    }
}