﻿using System;

namespace Egaku.Rendering.Pipeline.Common {
    public abstract class Renderer {
        
        
        public abstract void SetupPasses();
        
        public abstract void CreatePasses();
        
        public abstract void Init();

        public abstract void Reset();

        public abstract void Render();
    }
}