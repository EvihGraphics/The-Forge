﻿namespace Egaku.Rendering.Pipeline.Common {
    public abstract class RenderResourceManager {
        public abstract RenderContext GetCurrentRenderContext();
    }
}