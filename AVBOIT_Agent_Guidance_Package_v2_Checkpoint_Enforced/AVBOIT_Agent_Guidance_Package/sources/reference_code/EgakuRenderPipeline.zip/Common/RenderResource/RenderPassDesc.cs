﻿namespace Egaku.Rendering.Pipeline.Common {
    public struct RenderPassDesc {
        public int width;
        public int height;
        public int msaaSamples;
    }
}