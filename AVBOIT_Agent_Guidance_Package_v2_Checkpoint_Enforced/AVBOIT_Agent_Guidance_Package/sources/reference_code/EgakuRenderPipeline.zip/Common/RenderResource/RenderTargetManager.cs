﻿using UnityEngine;
using UnityEngine.Rendering;

namespace Egaku.Rendering.Pipeline.Common {
    public class RenderTargetManager {

        public static RenderTargetHandle Alloc(RenderTexture  texture) {
            return new RenderTargetHandle(RTHandles.Alloc(texture));
        }

        public static RenderTargetHandle Alloc(int width, int height) {
            return new RenderTargetHandle(RTHandles.Alloc(width,height));
        }

    }
}