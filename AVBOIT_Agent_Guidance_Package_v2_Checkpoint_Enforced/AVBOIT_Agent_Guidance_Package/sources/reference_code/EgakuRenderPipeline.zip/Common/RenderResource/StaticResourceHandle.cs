﻿namespace Egaku.Rendering.Pipeline.Common {
    public class StaticResourceHandle {
        
    }
}