﻿using UnityEngine;
using UnityEngine.Rendering;

namespace Egaku.Rendering.Pipeline.Common {
    public struct RenderTargetDesc {
        public RenderTexture color;
        public RenderTexture depth;
        public AttachmentDescriptor colorDesc;
        public AttachmentDescriptor depthDesc;
    }
    



}