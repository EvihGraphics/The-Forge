﻿namespace Egaku.Rendering.Pipeline.Common {
    public class RenderGraphSystem {
        
    }
}