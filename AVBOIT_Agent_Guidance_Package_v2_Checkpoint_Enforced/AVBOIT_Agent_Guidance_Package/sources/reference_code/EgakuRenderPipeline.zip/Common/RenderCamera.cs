﻿using UnityEngine;
using UnityEngine.Rendering;

namespace Egaku.Rendering.Pipeline.Common {
    public class RenderCamera {
        private Camera _internalCamera;
        
        public Camera InternalCamera => _internalCamera;
        
        private RenderTargetIdentifier _backBuffer = new(BuiltinRenderTextureType.CameraTarget);
        
        public RenderTargetIdentifier BackBuffer => _backBuffer;
        
        public int PixelWidth => _internalCamera.pixelWidth;
        public int PixelHeight => _internalCamera.pixelHeight;
        
        public RenderCamera(Camera internalCamera) {
            _internalCamera = internalCamera;
        }

        public void TryGetCullingParameters(out ScriptableCullingParameters p) {
            _internalCamera.TryGetCullingParameters(out p);
        }
        
        public RenderTargetHandle GetBackBuffer() {
            return RenderTargetManager.Alloc(_internalCamera.activeTexture);
        }
        
        
    }
}