﻿using System.Collections.Generic;

namespace Egaku.Rendering.Pipeline.Common {
    
    
    public class RenderPassManager {
        private struct PassNodeMeta {
            public RenderPassNode currentNode;
            public RenderPassNode[] referencingNodes;
            public RenderPassNode[] referencedNodes;
        }



        private Dictionary<RenderPassNode, PassNodeMeta> _passNodes = new();
        
        
        
        private class RenderGraph {
            
        }
        

    }
}