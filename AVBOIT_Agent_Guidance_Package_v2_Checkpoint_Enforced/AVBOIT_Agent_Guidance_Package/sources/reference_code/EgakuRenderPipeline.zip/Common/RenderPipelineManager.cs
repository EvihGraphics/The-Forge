﻿using System.Collections.Generic;

namespace Egaku.Rendering.Pipeline.Common {
    public class RenderPipelineManager {
        
        public static List<RenderPipeline> renderPipelines = new List<RenderPipeline>();
    }
}