﻿using System;

namespace Egaku.Rendering.Pipeline.Common{
    
    [AttributeUsage(AttributeTargets.Field)]
    public class MaterialPropertyAttribute : Attribute{
        
    }
}