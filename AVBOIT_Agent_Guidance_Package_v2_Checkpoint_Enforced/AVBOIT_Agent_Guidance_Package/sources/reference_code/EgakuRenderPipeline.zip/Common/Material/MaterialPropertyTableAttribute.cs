﻿using System;

namespace Egaku.Rendering.Pipeline.Common {
    
    [AttributeUsage(AttributeTargets.Class)]
    public class MaterialPropertyTableAttribute : Attribute {
        public CodeGenerationRequirements requiredCodeGeneration;
        
    }
}