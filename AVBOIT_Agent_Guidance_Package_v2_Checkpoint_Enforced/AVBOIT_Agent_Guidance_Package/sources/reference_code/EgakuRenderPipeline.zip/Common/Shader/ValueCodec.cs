﻿namespace Egaku.Rendering.Pipeline.Common.Shader {
    
    
    public interface IValueCodec<TEncoded,TDecoded> {
        public TDecoded Decode(TEncoded encodedValue);
        public TEncoded Encode(TDecoded decodedValue);
    }
}