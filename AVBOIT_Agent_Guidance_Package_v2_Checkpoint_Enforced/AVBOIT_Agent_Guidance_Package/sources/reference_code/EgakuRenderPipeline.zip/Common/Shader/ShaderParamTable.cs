﻿namespace Egaku.Rendering.Pipeline.Common.Shader {
    public interface ShaderParamTable {
        
        
    }
}