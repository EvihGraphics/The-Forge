﻿namespace Egaku.Rendering.Pipeline.Common.Shader {
    public enum Vector4Channels {
        X,
        Y,
        Z,
        W,
        XY,
        XZ,
        XW,
        YZ,
        YW,
        ZW,
        XYZ,
        XYW,
        XZW,
        YZW,
        XYZW
    }
}