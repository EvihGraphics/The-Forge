﻿using UnityEngine;

namespace Egaku.Rendering.Pipeline.Common.Shader {
    
    public abstract class ComputeShaderConfig : ScriptableObject{

        public abstract string FileURL { get; }
        
        public abstract string ComputeShaderName { get; }
        
        public abstract string FileDirectory { get; }
        
        public abstract ComputeShaderKernelConfig[] KernelConfigs { get; }
        
        public virtual string FileName  => $"{ComputeShaderName}.compute";
    }

    public abstract class ComputeShaderKernelConfig {
        public abstract string KernelSymbolName { get; }
        public abstract string[] IncludedFiles { get; }
     //   public abstract (uint,uint,uint) ThreadGroupSize { get; }
    }
}