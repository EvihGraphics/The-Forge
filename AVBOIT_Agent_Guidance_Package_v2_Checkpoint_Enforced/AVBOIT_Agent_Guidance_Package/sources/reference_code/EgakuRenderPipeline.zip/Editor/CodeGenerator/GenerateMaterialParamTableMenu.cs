﻿using Egaku.Rendering.Pipeline.Common;
using Egaku.Rendering.Pipeline.Utility;
using UnityEditor;
using UnityEngine;

namespace Egaku.Rendering.Pipeline.Editor.CodeGenerator {
    
    
    public class GenerateMaterialParamTableMenu {
        [MenuItem("Tools/Generate All Material Basic Codes")]
        static void GenerateAllMaterialBasicCodes()
        {
            ShaderCodeGenerator.GenerateAllBasicCodes();
        }
        
        [MenuItem("Tools/Generate All Compute Shader Asset Files")]
        static void GenerateAllComputeShaderAssetFiles()
        {
            ShaderCodeGenerator.GenerateAllComputeShaderAssetFiles();
        }
    }
}