﻿using Egaku.Rendering.Pipeline.Common;
using Egaku.Rendering.Pipeline.Utility;
using PlasticGui.WorkspaceWindow;

namespace Egaku.Rendering.Pipeline.Editor {
    public class RenderGraphEditorWindowContext {
        private RenderFeatureDesc[] _renderFeaturesDesc;
        
        public RenderFeatureDesc[] RenderFeaturesDesc { get => _renderFeaturesDesc; }

        public RenderGraphEditorWindowContext() {
            Refresh();
        }

        public void Refresh() {
            _renderFeaturesDesc = PipelineMetaUtils.GetAllRenderFeatureDesc().ToArray();
        }
    }
}