﻿using UnityEngine;

namespace Egaku.Rendering.Pipeline.Editor {
    
    
    public class RenderGraphBoard : ScriptableObject{
        
    }
}