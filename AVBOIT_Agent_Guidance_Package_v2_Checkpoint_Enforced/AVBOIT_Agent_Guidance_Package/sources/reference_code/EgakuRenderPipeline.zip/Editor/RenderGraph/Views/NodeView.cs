﻿using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine.UIElements;

namespace Egaku.Rendering.Pipeline.Editor {
    
    
    public class NodeView : Node{
        
        
        public IEnumerable<Port> GetPorts() {
            return mainContainer.Query<Port>().ToList();
        }

    }
}