﻿namespace Egaku.Rendering.Pipeline.Editor.Utils {
    public class RenderPassNodeViewCreator {
        
    }
}