﻿using Egaku.Rendering.Pipeline.Runtime;
using UnityEditor;
using UnityEngine;

namespace Egaku.Rendering.Pipeline.Editor {

    
    [CustomEditor(typeof(EgakuRenderPipelineAsset)),CanEditMultipleObjects]
    public class EgakuRenderPipelineAssetEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            
            EditorGUILayout.Space();
            if (GUILayout.Button("Refresh Pipeline"))
            {
                HandleRefreshButtonPress();
                Debug.Log("Pipeline Refreshed");
            }
        }

        private void HandleRefreshButtonPress() {
            EgakuRenderPipelineAsset.ResetPipeline();
        }
    }


}