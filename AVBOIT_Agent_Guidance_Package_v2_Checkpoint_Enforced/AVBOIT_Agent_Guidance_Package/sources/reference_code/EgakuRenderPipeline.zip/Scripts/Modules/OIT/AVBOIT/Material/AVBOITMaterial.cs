﻿namespace Modules.OIT.AVBOIT.Material {
    public class AVBOITMaterial {
        
    }
}