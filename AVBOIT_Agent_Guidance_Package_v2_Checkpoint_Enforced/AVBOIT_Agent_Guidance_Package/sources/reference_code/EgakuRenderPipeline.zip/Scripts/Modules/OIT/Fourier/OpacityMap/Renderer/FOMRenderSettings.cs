﻿using System;

namespace Modules.OIT.Fourier.OpacityMap.Renderer {
    
    [Serializable]
    public struct FOMRenderSettings {
        public int width;
        public int height;
    }
}