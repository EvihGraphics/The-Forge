﻿using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Modules.OIT.AVBOIT.Renderer.VirtualSliceBased.RenderResources {
    public struct VolumeSliceOccupancyBuffer {
        private RTHandle _handle;

        public int GetUAVSlotIndex() {
            return 1;
        }
    
        public void Setup(int sliceCount) { 
            RenderTextureDescriptor desc = new RenderTextureDescriptor(sliceCount, 1);
            desc.dimension = TextureDimension.Tex2D;
            desc.volumeDepth = 1;
            desc.depthBufferBits = 0;
            desc.colorFormat = RenderTextureFormat.ARGBFloat;
            desc.enableRandomWrite = true;
            RenderingUtils.ReAllocateIfNeeded(
                ref _handle,
                desc,
                FilterMode.Bilinear,
                TextureWrapMode.Clamp,
                name: "AVBOIT - Volume Slice Occupancy Buffer"
            );
        }
        
        public RTHandle GetHandle() {
            return _handle;
        }
    }
}