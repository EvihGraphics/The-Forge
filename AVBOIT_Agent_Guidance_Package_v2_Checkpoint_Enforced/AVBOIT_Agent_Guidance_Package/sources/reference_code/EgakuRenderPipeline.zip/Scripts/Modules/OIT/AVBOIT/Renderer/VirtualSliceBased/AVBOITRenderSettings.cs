﻿namespace Modules.OIT.AVBOIT.Renderer.VirtualSliceBased {
    public class AVBOITRenderSettings {
        
    }
}