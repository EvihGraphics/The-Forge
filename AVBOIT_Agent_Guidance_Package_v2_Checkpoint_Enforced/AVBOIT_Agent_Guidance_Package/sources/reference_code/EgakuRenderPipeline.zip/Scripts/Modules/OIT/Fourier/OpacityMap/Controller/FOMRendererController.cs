﻿using Common.Rendering;
using Modules.OIT.Fourier.OpacityMap.Renderer;
using UnityEngine;

namespace Modules.OIT.Fourier.OpacityMap.Controller {
    
    [ExecuteAlways]
    public class FOMRendererController : MonoBehaviour{
        
        [SerializeField]
        private FOMRenderSettings _settings;

        private FOMRenderer _renderer;

        private bool _loaded = false;


        void Load() {
            _renderer = CustomRendererManager.GetOrCreateCustomRenderer<FOMRenderer>();
            _renderer.SetRenderSettings(_settings);
            _loaded = _renderer.Initialize();
        }

        [ContextMenu("Reload")]
        public void GenerateTestCases() {
            _renderer = CustomRendererManager.GetOrCreateCustomRenderer<FOMRenderer>();
            _renderer.Reset();
            Load();
        }

        public void OnEnable() {
            Load();
            _renderer.SetEnabled();
        }

        public void Update() {
            if (_loaded == false && enabled) {
                Load();
                _renderer.SetEnabled();
            }
        }
    
        
        public void OnDisable() {
            _renderer.SetDisabled();
        }

        public void OnDestroy() {
            // _renderer.Destroy();
        }

    }
}