﻿using System;

namespace Modules.OIT.AVBOIT.Renderer.VirtualBlockBased {
    
    [Serializable]
    public struct AVBOITRenderSettings {
        [Serializable]
        public struct VirtualVolumeConfig {
            public int width;
            public int height;
            public int sliceCount;
        }
        
        [Serializable]
        public struct VolumeBlockConfig {
            public int widthDivisor;
            public int heightDivisor;
            public int sliceDivisor;
        }
        
        [Serializable]
        public struct PhysicalVolumeConfig {
            public int blockCount;
        }
        
        public VirtualVolumeConfig virtualVolumeConfig;
        public VolumeBlockConfig volumeBlockConfig;
        public PhysicalVolumeConfig physicalVolumeConfig;
        
        public bool useGPUBlending;

    }
}