﻿using Egaku.Rendering.Pipeline.Common;
using UnityEngine;

namespace Modules.OIT.Fourier.OpacityMap.Material {
    

    public class FOMShaderParamTable {
   
        [ShaderParam.Header(title = "Translucency Settings")]
        [ShaderParam.ConstantBuffer(name = "PerMaterial")]
        public struct TranslucencyDesc {
            [ShaderParam.ParamProperty(label = "Base Color")]
            public Color baseColor;
        }
    }
}