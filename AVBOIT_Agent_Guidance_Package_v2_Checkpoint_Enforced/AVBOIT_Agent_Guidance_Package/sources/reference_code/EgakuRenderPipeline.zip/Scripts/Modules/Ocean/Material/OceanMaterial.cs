﻿using UnityEngine;

namespace Modules.Ocean.Material {
    
    
    public class OceanMaterial : ScriptableObject{
        
        
    }
}