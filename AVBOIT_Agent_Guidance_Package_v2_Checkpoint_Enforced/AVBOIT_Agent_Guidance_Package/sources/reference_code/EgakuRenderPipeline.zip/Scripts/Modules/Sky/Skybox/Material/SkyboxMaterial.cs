﻿namespace Modules.Sky.Skybox.Material {
    public class SkyboxMaterial {
        
    }
}