﻿



using Egaku.Rendering.Pipeline.Common;
using Egaku.Rendering.Pipeline.Common.Shader;

namespace Modules.Sky.Skybox.Material {
    public class SkyboxShaderParamTable : ShaderParamTable{
        [ShaderParam.Header(title = "Skybox Settings")]
        [ShaderParam.ConstantBuffer(name = "PerMaterial")]
        public struct SkyboxDesc {
            [ShaderParam.ParamProperty(label = "Sun Light Intensity")]
            public float sunLightIntensity;
        }
    }
}