﻿


namespace Modules.Sky.Cloud.Volumetric.Material {
    public class VolumetricCloudMaterial {
        
    }
}