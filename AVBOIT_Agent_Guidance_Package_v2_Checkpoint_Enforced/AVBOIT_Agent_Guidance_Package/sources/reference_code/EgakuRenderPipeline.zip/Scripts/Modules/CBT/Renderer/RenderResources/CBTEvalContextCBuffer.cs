﻿using System.Runtime.InteropServices;
using Modules.CBT.Renderer.Shaders;
using UnityEngine;

namespace Modules.CBT.Renderer.RenderResources {
    public struct CBTEvalContextCBuffer {
        private GraphicsBuffer _buffer;

        public void Setup() {
            _buffer = new GraphicsBuffer(GraphicsBuffer.Target.Constant, 
                GraphicsBuffer.UsageFlags.LockBufferForWrite,
                1, Marshal.SizeOf<CBTEvalContextConstants>());
            _buffer.name = "CBT Eval Context Constants";
        }
        
        public GraphicsBuffer GetBuffer() {
            return _buffer;
        }
        
        public void Release() {
            if (_buffer != null) {
                _buffer.Release();
            }
        }
    }
}