﻿using System.Runtime.InteropServices;
using Modules.CBT.Renderer.Shaders;
using UnityEngine;

namespace Modules.CBT.Renderer.RenderResources {
    public struct CBTUpdateContextCBuffer {
        private GraphicsBuffer _buffer;

        public void Setup() {
            // build cbt update context constant buffer for update pass.
            _buffer = new GraphicsBuffer(GraphicsBuffer.Target.Constant, 
                GraphicsBuffer.UsageFlags.LockBufferForWrite,
                1, Marshal.SizeOf<CBTUpdateContextConstants>());
            _buffer.name = "CBT Update Context Constants";
        }
        
        public GraphicsBuffer GetBuffer() {
            return _buffer;
        }
        
        public void Release() {
            if (_buffer != null) {
                _buffer.Release();
            }
        }
    }
}