﻿using UnityEngine;

namespace Modules.CBT.Renderer.RenderResources {
    public struct CBTEvalResultBuffer {
        private GraphicsBuffer _buffer;

        public void Setup(int cbtMaxNodeCount) {
            _buffer = new GraphicsBuffer( GraphicsBuffer.Target.Structured,cbtMaxNodeCount,
                sizeof(uint));
            _buffer.SetCounterValue(0);
            _buffer.name = "CBT Eval Result Buffer";
        }
        
        public GraphicsBuffer GetBuffer() {
            return _buffer;
        }
        
        public void Release() {
            if (_buffer != null) {
                _buffer.Release();
            }
        }
    }
}