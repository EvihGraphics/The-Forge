﻿namespace Modules.CBT.Renderer.Common {
    public struct CBTNode {
        public int id;
        public int depth;
    }
}