﻿using System;

namespace Modules.CBT.Renderer {
    
    [Serializable]
    public struct CBTMeshRenderSettings {
        public int cbtMaxDepth;
        public int meshletSubdivisionLevel;
        public int targetPrimitiveViewportPixelCount;
    }
}