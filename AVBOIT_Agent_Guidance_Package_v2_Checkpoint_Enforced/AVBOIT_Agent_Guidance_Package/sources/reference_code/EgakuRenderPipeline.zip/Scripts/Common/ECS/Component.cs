﻿namespace Common.ECS {
    
    
    public abstract class Component {
        
    }
}