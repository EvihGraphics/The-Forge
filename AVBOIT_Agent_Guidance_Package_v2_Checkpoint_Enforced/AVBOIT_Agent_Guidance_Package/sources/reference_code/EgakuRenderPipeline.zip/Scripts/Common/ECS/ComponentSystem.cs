﻿namespace Common.ECS {
    
    
    
    public abstract class ComponentSystem {
        
    }
}