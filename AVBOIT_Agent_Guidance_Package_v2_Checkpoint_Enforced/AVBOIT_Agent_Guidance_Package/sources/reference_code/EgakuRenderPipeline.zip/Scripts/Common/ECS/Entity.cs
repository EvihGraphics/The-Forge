﻿using UnityEngine;

namespace Common.ECS {
    
    public abstract class Entity : MonoBehaviour{
        
    }
    
    
}