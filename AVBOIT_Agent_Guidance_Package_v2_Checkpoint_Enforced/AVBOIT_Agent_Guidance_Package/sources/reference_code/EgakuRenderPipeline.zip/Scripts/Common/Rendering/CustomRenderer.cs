﻿using Common.ECS;

namespace Common.Rendering {
    
    
    
    public abstract class CustomRenderer : ComponentSystem {
        public abstract bool Valid { get; }
        public abstract bool Enabled { get; }
        
        public abstract bool Initialize();

        public abstract bool Destroy();

    }
    
    public abstract class CustomRenderer<T> : CustomRenderer where T : CustomRenderInstance {
        
        public abstract bool TryAddRenderInstance(T instance);
        
        public abstract bool TryRemoveRenderInstance(T instance);
        
    }
}