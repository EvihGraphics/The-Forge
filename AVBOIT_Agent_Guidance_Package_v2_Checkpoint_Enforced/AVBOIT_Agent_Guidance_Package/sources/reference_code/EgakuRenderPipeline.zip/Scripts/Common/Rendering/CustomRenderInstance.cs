﻿using Common.ECS;

namespace Common.Rendering {
    public abstract class CustomRenderInstance {
        public abstract bool Valid { get; }
        
        public abstract bool Enabled { get; }
    }
}