﻿using System.Runtime.InteropServices;

namespace Common {
    [StructLayout(LayoutKind.Sequential)]
    struct DispatchIndirectArgs {
        public uint threadGroupsX;
        public uint threadGroupsY;
        public uint threadGroupsZ;
    }

}