﻿using Modules.CBT.Renderer;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering;


namespace RenderFeatures.Ocean.RenderPasses {
    public class CBTUpdatePass : ScriptableRenderPass{
        
        private CBTMeshRenderer _renderer;
        
        public void SetRenderer(CBTMeshRenderer renderer) {
            _renderer = renderer;
        }
        
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {
            
        }

        public override void OnCameraCleanup(CommandBuffer cmd) {
            
        }
        
		public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
            if (_renderer != null && _renderer.Enabled) {
                _renderer.RecordCBTUpdateComputeCommands(ref ctx, data.cameraData.camera);
            }
        }
    }
}