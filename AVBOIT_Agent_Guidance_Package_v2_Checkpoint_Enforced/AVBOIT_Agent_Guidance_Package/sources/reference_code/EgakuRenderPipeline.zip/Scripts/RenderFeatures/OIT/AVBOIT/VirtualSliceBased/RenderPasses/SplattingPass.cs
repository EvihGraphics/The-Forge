﻿
using Modules.OIT.AVBOIT.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    
    public class SplattingPass : ScriptableRenderPass{
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {
            
        }

        public override void OnCameraCleanup(CommandBuffer cmd) {
           
        }
        
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
        //    AVBOITRenderer.RecordRenderCommandsSplattingPass(ref ctx,ref data);
        }
    }
}