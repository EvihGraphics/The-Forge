﻿using Modules.OIT.AVBOIT.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    public class TranslucencyForwardPass : ScriptableRenderPass{
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {
            
        }

        public override void OnCameraCleanup(CommandBuffer cmd) {
           
        }
        
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
         //   AVBOITRenderer.RecordRenderCommandsTranslucencyForwardPass(ref ctx,ref data);
        }
    }
}