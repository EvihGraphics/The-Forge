﻿using Modules.OIT.AVBOIT.Renderer.VirtualBlockBased;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualBlockBased.RenderPasses {
    
    public class VolumeBlockLutBuildingPass : ScriptableRenderPass{

        private AVBOITRenderer _renderer;

        public VolumeBlockLutBuildingPass(AVBOITRenderer renderer) {
            _renderer = renderer;
        }
        
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
            _renderer.RecordRenderCommandsVolumeBlockLutBuildingPass(ref ctx,ref data);
        }
    }
}