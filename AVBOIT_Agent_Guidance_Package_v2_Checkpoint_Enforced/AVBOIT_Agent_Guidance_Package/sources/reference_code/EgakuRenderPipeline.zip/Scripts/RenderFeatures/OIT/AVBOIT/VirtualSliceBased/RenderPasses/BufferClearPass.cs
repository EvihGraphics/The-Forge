﻿using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    
    public class BufferClearPass  : ScriptableRenderPass{

        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
          //  AVBOITRenderer.RecordRenderCommandsBufferClearPass(ref ctx,ref data);
        }
    }
}