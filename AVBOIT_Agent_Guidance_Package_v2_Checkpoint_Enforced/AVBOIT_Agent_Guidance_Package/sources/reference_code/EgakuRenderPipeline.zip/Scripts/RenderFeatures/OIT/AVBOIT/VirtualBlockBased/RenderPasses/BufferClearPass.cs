﻿using Modules.OIT.AVBOIT.Renderer.VirtualBlockBased;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualBlockBased.RenderPasses {
    public class BufferClearPass : ScriptableRenderPass {
        
        private AVBOITRenderer _renderer;

        public BufferClearPass(AVBOITRenderer renderer) {
            _renderer = renderer;
        }
        
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {

        }

        public override void OnCameraCleanup(CommandBuffer cmd) {

        }

        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
            _renderer.RecordRenderCommandsBufferClearPass(ref ctx, ref data);
        }
    }
}