﻿using Modules.OIT.AVBOIT.Renderer.VirtualBlockBased;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualBlockBased.RenderPasses {
    public class DebugVolumeBufferPass  : ScriptableRenderPass {
        private AVBOITRenderer _renderer;
        
        public DebugVolumeBufferPass(AVBOITRenderer renderer) {
            _renderer = renderer;
        }
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
            _renderer.RecordRenderCommandsBufferClearPass(ref ctx, ref data);
        }
    }
}