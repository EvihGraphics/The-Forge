﻿using Modules.OIT.AVBOIT.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    
    public class DepthWarpLutBuildingPass : ScriptableRenderPass{

        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
        //    AVBOITRenderer.RecordRenderCommandsVolumeBlockLutBuildingPass(ref ctx,ref data);
        }
    }
}