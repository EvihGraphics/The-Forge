﻿using Modules.OIT.AVBOIT.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    public class VolumeTransmittanceIntegrationPass : ScriptableRenderPass{
        
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {
            
        }

        public override void OnCameraCleanup(CommandBuffer cmd) {
           
        }
        
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
       //     AVBOITRenderer.RecordRenderCommandsVolumeTransmittanceIntegrationPass(ref ctx,ref data);
        }
    }
}