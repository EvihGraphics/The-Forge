﻿using Modules.OIT.AVBOIT.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.OIT.AVBOIT.VirtualSliceBased.RenderPasses {
    public class VolumeOccupancyCollectionPass : ScriptableRenderPass{

        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
         //   AVBOITRenderer.RecordRenderCommandsVolumeOccupancyCollectionPass(ref ctx,ref data);
        }
    }
}