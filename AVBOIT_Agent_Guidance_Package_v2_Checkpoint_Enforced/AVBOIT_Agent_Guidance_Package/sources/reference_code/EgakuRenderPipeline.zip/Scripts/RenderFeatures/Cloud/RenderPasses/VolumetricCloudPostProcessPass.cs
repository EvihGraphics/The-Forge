﻿using Modules.Sky.Cloud.Volumetric.Renderer;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RenderFeatures.Cloud.RenderPasses {
    
    
    public class VolumetricCloudPostProcessPass: ScriptableRenderPass {
        private VolumetricCloudRenderer _renderer;
        
        public void SetRenderer(VolumetricCloudRenderer renderer) {
            _renderer = renderer;
        }
        
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData) {
            
        }

        public override void OnCameraCleanup(CommandBuffer cmd) {
           
        }
        
        public override void Execute(ScriptableRenderContext ctx, ref RenderingData data) {
            if (_renderer != null && _renderer.Enabled) {
                _renderer.RecordRenderCommandsOctahedronMarchingPass(ref ctx, ref data);
            }
        }
    }
}