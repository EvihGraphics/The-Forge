﻿#pragma once
#ifndef CBUFFER_HLSL
#define CBUFFER_HLSL
#include "UnityCommon.hlsl"

#define CBUFFER_BEGIN(name) CBUFFER_START(name)
#define CBUFFER_END };

#endif
