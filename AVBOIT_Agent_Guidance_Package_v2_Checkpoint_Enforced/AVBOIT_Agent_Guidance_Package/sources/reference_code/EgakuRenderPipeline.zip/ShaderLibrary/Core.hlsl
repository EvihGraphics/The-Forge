﻿#pragma once
#ifndef CORE_HLSL
#define CORE_HLSL

#ifdef UNIVERSAL_RENDER_PIPELINE
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#else
#include "Input.hlsl"
#endif

#include "Common.hlsl"
#include "Texture.hlsl"
#include "Context.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/SpaceTransforms.hlsl"

#endif
