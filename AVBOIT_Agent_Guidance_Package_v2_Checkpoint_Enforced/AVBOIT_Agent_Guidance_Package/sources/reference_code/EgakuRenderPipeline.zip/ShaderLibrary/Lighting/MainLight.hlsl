﻿#ifndef MAIN_LIGHT_HLSL
#define MAIN_LIGHT_HLSL

struct MainLightDesc
{
    float3 position;
    float3 direction;
    float3 intensity;
};

#endif