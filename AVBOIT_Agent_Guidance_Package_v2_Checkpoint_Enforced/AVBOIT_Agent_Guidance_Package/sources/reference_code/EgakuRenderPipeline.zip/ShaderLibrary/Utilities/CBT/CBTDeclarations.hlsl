﻿#ifndef CBTDECLARATIONS_HLSL
#define CBTDECLARATIONS_HLSL

#ifndef CBT_HEAP_BUFFER_BINDING
#ifdef CBT_FLAG_WRITE
#define CBT_HEAP_BUFFER_BINDING register(u0)
#else
#define CBT_HEAP_BUFFER_BINDING register(t0)
#endif
#endif

#ifdef CBT_FLAG_WRITE
RWStructuredBuffer<uint> u_CbtBuffer : CBT_HEAP_BUFFER_BINDING;
#else
StructuredBuffer<uint> u_CbtBuffer : CBT_HEAP_BUFFER_BINDING;
#endif

#include "CBTTypedef.hlsl"

#endif
