﻿#pragma once
#ifdef CBTCOMMON_HLSL
#define CBTCOMMON_HLSL
#include "CBTDeclarations.hlsl"



#endif
