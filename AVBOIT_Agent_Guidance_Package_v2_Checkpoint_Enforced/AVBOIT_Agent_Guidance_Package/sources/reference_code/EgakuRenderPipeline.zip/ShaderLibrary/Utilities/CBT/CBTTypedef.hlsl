﻿#pragma once
#ifndef CBT_TYPEDEF_HLSL
#define CBT_TYPEDEF_HLSL

// data structures
struct cbt_Node {
    uint id;    // heapID
    int depth;  // findMSB(heapID) := node depth
};

struct leb_DiamondParent
{
    cbt_Node base, top;
};

#endif
