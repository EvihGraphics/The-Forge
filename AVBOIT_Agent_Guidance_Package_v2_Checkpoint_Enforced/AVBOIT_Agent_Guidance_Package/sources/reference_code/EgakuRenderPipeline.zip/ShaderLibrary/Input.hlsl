﻿#pragma once
#ifndef INPUT_HLSL
#define INPUT_HLSL
#include "UnityInput.hlsl"
#endif
