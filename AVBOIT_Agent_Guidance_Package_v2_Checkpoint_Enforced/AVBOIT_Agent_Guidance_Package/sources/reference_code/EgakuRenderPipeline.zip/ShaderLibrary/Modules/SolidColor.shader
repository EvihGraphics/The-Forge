﻿Shader "Egaku Render Pipeline/SolidColor"
{
    Properties
    {
        _SolidColor ("Color", Color) = (1,1,1,1)
    }
    SubShader
    {
        HLSLINCLUDE
        #include "SolidColor.hlsl"
     
        ENDHLSL

        Pass{
            Tags { "LightMode" = "Basic"}
              

            HLSLPROGRAM
            #pragma multi_compile_instancing
            #pragma vertex Vertex
            #pragma fragment Fragment
            #pragma target 3.0
            ENDHLSL
        }
        
    

    }

}