﻿#ifndef BLIT_PARAM_TABLE_HLSL
#define BLIT_PARAM_TABLE_HLSL
#include "Packages/io.github.chiikusa.egaku-render-pipeline/ShaderLibrary/Core.hlsl"


Texture2D _MainTex;
SamplerState sampler_MainTex;
float4 _Color;

#endif
