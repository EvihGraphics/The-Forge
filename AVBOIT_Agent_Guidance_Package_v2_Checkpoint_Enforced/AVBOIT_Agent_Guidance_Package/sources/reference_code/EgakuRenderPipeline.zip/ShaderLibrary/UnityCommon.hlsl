﻿#pragma once
#ifndef UNITY_COMMON_HLSL
#define UNITY_COMMON_HLSL
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Common.hlsl"

#endif
