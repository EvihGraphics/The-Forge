﻿#pragma once
#ifndef VIRTUAL_VOLUME_CONFIG_INTERFACE_HLSL
#define VIRTUAL_VOLUME_CONFIG_INTERFACE_HLSL

uint3 VirtualVolumeConfig_GetVolumeDimensionsInBlock();
uint3 VirtualVolumeConfig_GetVolumeBlockDimensions();


#endif
