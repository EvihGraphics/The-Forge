﻿#pragma once
#ifndef PHYSICAL_VOLUME_CONFIG_INTERFACE_HLSL
#define PHYSICAL_VOLUME_CONFIG_INTERFACE_HLSL

uint3 PhysicalVolumeConfig_GetVolumeDimensions();
uint3 PhysicalVolumeConfig_GetVolumeBlockDimensions();


float PhysicalVolume_TransformVirtualVolumeBlockIndexToPhysical(float virtualVolumeBlockIndex);

#endif
