﻿#pragma once
#ifndef COMMON_UTILS_HLSL
#define COMMON_UTILS_HLSL
#include "Assets/Shaders/HLSLInclude/CommonShaderUtils.hlsl"




#endif