// This file was generated from Modules.OIT.Fourier.OpacityMap.Material.FOMShaderParamTable by Egaku.Rendering.Pipeline.Common.ShaderCodeGenerator.
// Please do not modify it manually.
// Codes in this file are functioned as material parameter table, which is used to declare some uniform variables and macro constants.

#ifndef FourierOpacityMap_ParamTable_hlsl
#define FourierOpacityMap_ParamTable_hlsl
#include "Packages/io.github.chiikusa.egaku-render-pipeline/ShaderLibrary/Core.hlsl"


CBUFFER_BEGIN(PerMaterial)
	float4 _Translucency_baseColor;
CBUFFER_END






#endif // FourierOpacityMap_ParamTable_hlsl
