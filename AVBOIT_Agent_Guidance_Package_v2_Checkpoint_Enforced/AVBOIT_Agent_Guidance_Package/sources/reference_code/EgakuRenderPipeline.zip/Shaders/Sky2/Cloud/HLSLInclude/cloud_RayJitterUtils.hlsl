﻿#ifndef CLOUD_RAY_JITTER_UTILS_HLSL
#define CLOUD_RAY_JITTER_UTILS_HLSL

struct JitterDesc
{
    bool jitter;
};

float3 JitterPoint(float3 p,JitterDesc desc)
{
    return p;
}

#endif
