﻿#pragma once
#ifndef ATMOSPHERE_VOLUME_LIGHTING_HLSL
#define ATMOSPHERE_VOLUME_LIGHTING_HLSL

#include "Assets/Shaders/Sky/Basic/VolumeBase/VolumeLighting.hlsl"

float GetPhase_Rayleigh(float cosTheta)
{
    return RayleighPhase(cosTheta);
}

float GetPhase_Mie(float cosTheta,float anisotropy)
{
    return HGPhase(anisotropy,cosTheta);
}


#endif
