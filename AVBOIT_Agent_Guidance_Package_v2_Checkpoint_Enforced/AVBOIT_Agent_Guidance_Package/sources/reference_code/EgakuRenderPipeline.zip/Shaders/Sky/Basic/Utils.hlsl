﻿#pragma once
#ifndef SKY_UTILS_HLSL
#define SKY_UTILS_HLSL
#include "Assets/Shaders/Infrastructure/Utils.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DeclareDepthTexture.hlsl"

#endif