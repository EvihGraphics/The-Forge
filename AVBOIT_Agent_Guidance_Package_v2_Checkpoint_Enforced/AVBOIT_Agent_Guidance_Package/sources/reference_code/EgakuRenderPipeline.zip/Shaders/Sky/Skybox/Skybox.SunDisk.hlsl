﻿#pragma once
#ifndef SKYBOX_SUNDISK_HLSL
#define SKYBOX_SUNDISK_HLSL


float GetSunDiskSolidAngle()
{
    return 0;
}

bool IsDirectionInSunDisk(float3 sunDiskDirection,float3 direction){
    const float pi = 3.1415926535897932384626433832795;
    float diskD = cos(0.2725 *  (pi / 180.0f));
    float d = dot(direction, sunDiskDirection);
    return saturate(d - diskD);
}



#endif
