Shader "MyCustom/Sky/Skybox"
{
	Properties
	{
		
		[Header(Skybox Settings)]
		_Skybox_sunLightIntensity("Sun Light Intensity", Float) = 0.0
	}
	
	HLSLINCLUDE
		#define UNIVERSAL_RENDER_PIPELINE 
		#include "Skybox.ParamTable.hlsl"
	ENDHLSL
	
	SubShader
	{
		Tags
		{
			"RenderPipeline" = "UniversalPipeline"
		}
		
		Pass
		{
			
			Cull Off
			ZWrite Off
			
			HLSLPROGRAM
				#include "Skybox.hlsl"
				
				#pragma target 4.0
				#pragma vertex Vert
				#pragma fragment Frag
			ENDHLSL
		}
		
	}
}
