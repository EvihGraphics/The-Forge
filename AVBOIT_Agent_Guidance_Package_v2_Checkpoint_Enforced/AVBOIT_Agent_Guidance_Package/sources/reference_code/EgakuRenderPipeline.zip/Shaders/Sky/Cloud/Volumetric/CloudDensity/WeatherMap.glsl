﻿#pragma once
#ifndef WEATHER_MAP_HLSL
#define WEATHER_MAP_HLSL


float SampleWeatherMap(MapTexture weatherMap,float2 coords)
{
    float3 sampledVal = SampleTexture(weatherMap.mapTex,coords,weatherMap.sampleDesc);
    return dot(sampledVal,weatherMap.channelWeights);
}

#endif