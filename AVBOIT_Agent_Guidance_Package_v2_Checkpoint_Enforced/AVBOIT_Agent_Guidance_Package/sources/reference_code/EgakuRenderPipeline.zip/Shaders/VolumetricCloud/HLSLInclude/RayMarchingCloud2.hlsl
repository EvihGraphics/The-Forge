﻿#ifndef RAY_MARCHING_CLOUD2_HLSL
#define RAY_MARCHING_CLOUD2_HLSL


struct CloudDensityDesc
{
    
};

struct CloudDesc
{
    
};

#endif
