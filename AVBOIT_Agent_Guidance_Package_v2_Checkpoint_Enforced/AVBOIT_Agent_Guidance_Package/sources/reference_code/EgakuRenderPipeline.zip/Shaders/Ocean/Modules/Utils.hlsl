﻿#ifndef OCEAN_UTILS_HLSL
#define OCEAN_UTILS_HLSL
#include "Assets/Shaders/Infrastructure/Utils.hlsl"


#endif
