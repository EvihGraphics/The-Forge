﻿#ifndef SMOOTH_NOISE_HLSL
#define SMOOTH_NOISE_HLSL
#include "Packages/io.github.chiikusa.egaku-render-pipeline/ShaderLibrary/Texture.hlsl"
#include "Ocean.ParamStruct.hlsl"


float SampleSmoothNoiseMap(float2 uv)
{
    float noise = SampleTextureLevel(FetchParam(SmoothNoiseMapDesc).tex, sampler_LinearRepeat, uv, 0).r;
    return noise;
}

#endif
