﻿#ifndef REFLECTION_TEXTURE_HLSL
#define REFLECTION_TEXTURE_HLSL

Texture2D _ReflectionTex;

float4 SampleReflectionTexture(float2 uv)
{
    return SampleTexture(_ReflectionTex,sampler_LinearClamp,uv);
}

#endif
