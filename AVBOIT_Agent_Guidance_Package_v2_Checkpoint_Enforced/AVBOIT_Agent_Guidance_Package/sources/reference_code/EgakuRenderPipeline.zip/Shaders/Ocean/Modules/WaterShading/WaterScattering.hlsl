﻿#ifndef WATER_SCATTERING_HLSL
#define WATER_SCATTERING_HLSL
#include "../Utils.hlsl"
#include "WaterShadingHelperStructs.hlsl"

float3 CalcScatteringFactor(WaterShadingContext context)
{
    DeclareParamFetch(WaterVolumetricShadingDesc,shadingDesc);
    float vertexNoV = dot(context.vertexNormalWS, context.viewDir);
    float pixelNoV = dot(context.pixelNormalWS, context.viewDir);
    float3 scatter = lerp(vertexNoV, abs(pixelNoV),  shadingDesc.subscatteringDetail);
    scatter -= GetVertical(context.viewDir);
    scatter = saturate(scatter);
    scatter = pow(scatter, shadingDesc.subscatteringPower);
    scatter = saturate(scatter * shadingDesc.subscatteringScale);
    return scatter;
}

#endif
