﻿


using System.Collections.Generic;
using Egaku.Rendering.Pipeline.Common;
using Egaku.Rendering.Pipeline.Runtime;

namespace Egaku.Rendering.Pipeline.Runtime {
    public class SolidColorRenderFeature : RenderFeature{
        
    }
}