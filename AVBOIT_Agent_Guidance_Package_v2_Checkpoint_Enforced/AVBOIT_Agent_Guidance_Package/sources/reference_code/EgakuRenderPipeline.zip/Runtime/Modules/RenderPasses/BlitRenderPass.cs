﻿using Egaku.Rendering.Pipeline.Common;
using UnityEditor.VersionControl;
using UnityEngine;
using UnityEngine.Rendering;

namespace Egaku.Rendering.Pipeline.Runtime {
    public class BlitRenderPass : RenderPass {
        
        public BlitRenderPass() {
            Order = 2;
            Name = nameof(SolidColorPostProcessPass);
        }


        
        public static readonly string Tag = nameof(BlitRenderPass);
        public RenderTexture Source { get; set; }
        
        public RenderTargetIdentifier Destination { get; set; }

        public override void Execute(RenderContext context) {
            CommandBuffer cb = CommandBufferPool.Get();
            cb.Blit(Source,Destination);
            RenderCommand.InjectCommandsAndClear(context,cb);
            CommandBufferPool.Release(cb);
        }
        
    }
}