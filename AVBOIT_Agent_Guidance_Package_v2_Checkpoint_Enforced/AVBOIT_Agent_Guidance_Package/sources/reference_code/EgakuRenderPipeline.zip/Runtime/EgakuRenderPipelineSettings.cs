﻿namespace Egaku.Rendering.Pipeline.Runtime {
    public class EgakuRenderPipelineSettings {
        
    }
}