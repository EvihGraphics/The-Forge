﻿using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace Egaku.Rendering.Pipeline.Runtime {
    
    [CreateAssetMenu(menuName = "Rendering/Egaku Render Pipeline")]
    public class EgakuRenderPipelineAsset : RenderPipelineAsset {
        
        
        private static EgakuRenderPipeline _currentPipeline;


        public static void ResetPipeline() {
            _currentPipeline.Reset();
        }

        protected override RenderPipeline CreatePipeline() {
            _currentPipeline = new();
            return _currentPipeline;
        }
        
    }
}